package com.example.lenovo.hmm;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class Login extends AppCompatActivity {

  private Button login;
  private EditText email;
  private EditText pass;
  private FirebaseAuth firebaseAuth;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login);
    login = findViewById(R.id.login);
    email = findViewById(R.id.email);
    pass = findViewById(R.id.pass);
    firebaseAuth = FirebaseAuth.getInstance();
  }


  public void login_Click(View v){
    final ProgressDialog progressDialog = ProgressDialog.show(Login.this,"Please wait..","Processing..", true);
    (firebaseAuth.signInWithEmailAndPassword(email.getText().toString(),pass.getText().toString()))
            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
              @Override
              public void onComplete(@NonNull Task<AuthResult> task) {
                progressDialog.dismiss();

                if (task.isSuccessful()){
                  Toast.makeText(Login.this, "Login Success!", Toast.LENGTH_LONG).show();
                  Intent i = new Intent(Login.this, Home.class);

                  startActivity(i);
                }
                else {
                  Log.e("ERROR!!", task.getException().toString());
                  Toast.makeText(Login.this, task.getException().getMessage(),Toast.LENGTH_LONG).show();
                }
              }
            });
  }
}
