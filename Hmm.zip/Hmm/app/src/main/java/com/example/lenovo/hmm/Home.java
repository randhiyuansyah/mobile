package com.example.lenovo.hmm;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

public class Home extends AppCompatActivity {

    private BottomNavigationView navigation;
    private FrameLayout homeFrame;

    private HomeFragment homeFragment;
    private AkunFragment akunFragment;
    private CheckUpFragment checkUpFragment;

    private ImageButton caridoct;
    private ImageButton carirs;
    private ImageButton ambulance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        navigation = findViewById(R.id.navigation);
        homeFrame = findViewById(R.id.homeFrame);

        caridoct = findViewById(R.id.caridoct);
        carirs = findViewById(R.id.carirs);
        ambulance = findViewById(R.id.ambulance);

        homeFragment = new HomeFragment();
        akunFragment = new AkunFragment();
        checkUpFragment = new CheckUpFragment();

        navigation.setOnNavigationItemSelectedListener(navListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.homeFrame, new HomeFragment()).commit();

        caridoct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Home.this, CariDokter.class);
                startActivity(i);

            }
        });

        carirs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ih = new Intent(Home.this, MapsActivity.class);
                startActivity(ih);

            }
        });

        ambulance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ig = new Intent(Home.this, Ambulance.class);
                startActivity(ig);

            }
        });
      }
    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    Fragment selected_fragment = null;
                    switch (item.getItemId()){
                        case R.id.navigation_home:
                            selected_fragment = new HomeFragment();
                            break;
                        case R.id.navigation_check_up:
                            selected_fragment = new CheckUpFragment();
                            break;
                        case R.id.navigation_akun:
                            selected_fragment = new AkunFragment();
                            break;
                    }
                    getSupportFragmentManager().beginTransaction().replace(R.id.homeFrame, selected_fragment).commit();

                    return true;
                }
            };
    }
